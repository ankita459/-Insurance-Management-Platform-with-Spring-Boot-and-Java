package com.insurance.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.insurance.controller.InsurancePolicies;
import com.insurance.model.Client;
import com.insurance.model.InsurancePolicy;

public interface models {
	
	@Repository
	public interface ClientRepository extends JpaRepository<Client, Long> {
	}

	@Repository
	public interface InsurancePolicyRepository extends JpaRepository<InsurancePolicy, Long> {
	}

	@Repository
	public interface InsuranceClaimRepository extends JpaRepository<InsurancePolicies, Long> {
	}

}
