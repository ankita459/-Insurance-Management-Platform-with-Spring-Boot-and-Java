package com.insurance.repository;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.insurance.model.Client;
import com.insurance.repository.models;


@Service
public class domainmodels {
	
	 @Autowired
	    private Client clientRepository;

	    public List<Client> getAllClients() {
	        return Client.findAll();
	    }

	    public Client getClientById(Long id) {
	        return (Client) ((Object) Client.findById(id));
	    }

	    public Client createClient(Client client) {
	        return Client.save(client);
	    }
}
