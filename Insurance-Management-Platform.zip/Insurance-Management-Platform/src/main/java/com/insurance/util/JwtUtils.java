package com.insurance.util;

import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

import jakarta.servlet.http.HttpServletResponse;


public class JwtUtils {
	
	static final long EXPIRATION_TIME = 864_000_000; // 10 days
    static final String SECRET = "secret";
    static final String TOKEN_PREFIX = "Bearer";
    static final String HEADER_STRING = "Authorization";
	private static final Function GrantedAuthority = null;

    public static void addAuthentication(HttpServletResponse res, String username, List<GrantedAuthority> authorities) {
        String authoritiesString = (String) authorities.stream()
                .map(GrantedAuthority)
                .collect(Collectors.joining(","));
    }
}
