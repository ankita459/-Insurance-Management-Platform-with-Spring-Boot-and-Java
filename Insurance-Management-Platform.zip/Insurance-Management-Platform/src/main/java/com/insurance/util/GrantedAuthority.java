package com.insurance.util;

public class GrantedAuthority {

}
