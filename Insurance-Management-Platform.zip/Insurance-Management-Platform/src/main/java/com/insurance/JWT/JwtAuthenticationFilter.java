package com.insurance.JWT;

import java.io.IOException;
import java.util.ArrayList;

import javax.security.sasl.AuthenticationException;

import org.springframework.boot.autoconfigure.neo4j.Neo4jProperties.Authentication;
import org.springframework.jdbc.support.JdbcUtils;
import org.springframework.util.AntPathMatcher;

import com.insurance.exception.InsuranceException;
import com.insurance.exception.InsuranceExceptionHandler;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureException;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class JwtAuthenticationFilter extends InsuranceException {
	
	public JwtAuthenticationFilter() {
        super(new AntPathMatcher("/api/**"));
    }

    public boolean attemptAuthentication(HttpServletRequest request, HttpServletResponse response)
            throws AuthenticationException, IOException, ServletException {
        String header = request.getHeader("Authorization");

        if (header == null || !header.startsWith("Bearer ")) {
            throw new RuntimeException("JWT token is missing or invalid");
        }

        String authenticationToken = header.substring(7);

        Claims claims;
        try {
            claims = Jwts.parser().setSigningKey("secret").parseClaimsJws(authenticationToken).getBody();
        } catch (SignatureException e) {
            throw new RuntimeException("JWT token is missing or invalid");
        }

        String username = claims.getSubject();
        ArrayList<String> roles = (ArrayList<String>) claims.get("roles");

        if (username == null) {
            throw new RuntimeException("JWT token is missing or invalid");
        }

        if (roles == null) {
            roles = new ArrayList<>();
        }

        return getAuthenticationManager().authenticate(new InsuranceExceptionHandler());
    }

    private HttpServletRequest getAuthenticationManager() {
		// TODO Auto-generated method stub
		return null;
	}

	

}
