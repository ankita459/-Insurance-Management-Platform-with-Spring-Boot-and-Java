package com.insurance.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.insurance.model.Claim;

@RestController
@RequestMapping("/api/claims")
public class Claims {
	

    // In-memory database of claims
    private static final Map<Integer, Claim> claimsDB = new HashMap<>();
    private static final AtomicInteger claimIdGenerator = new AtomicInteger(1);

    // GET all claims
    @GetMapping
    public ResponseEntity<List<Claim>> getAllClaims() {
        List<Claim> claims = new ArrayList<>(claimsDB.values());
        return new ResponseEntity<>(claims, HttpStatus.OK);
    }

    // GET claim by ID
    @GetMapping("/{id}")
    public ResponseEntity<Claim> getClaimById(@PathVariable int id) {
        Claim claim = claimsDB.get(id);
        if (claim != null) {
            return new ResponseEntity<>(claim, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    // POST create a new claim
    @PostMapping
    public ResponseEntity<Claim> createClaim(@RequestBody Claim claim) {
        int claimId = claimIdGenerator.getAndIncrement();
        ((Claim) claim).setId(claimId);
        claimsDB.put(claimId, claim);
        return new ResponseEntity<>(claim, HttpStatus.CREATED);
    }

    // PUT update claim information
    @PutMapping("/{id}")
    public ResponseEntity<Claim> updateClaim(@PathVariable int id, @RequestBody Claim claim) {
        Claim existingClaim = claimsDB.get(id);
        if (existingClaim != null) {
            claim.setId(((Claim) existingClaim).getId());
            claimsDB.put(id, claim);
            return new ResponseEntity<>(claim, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    // DELETE a claim by ID
    @DeleteMapping("/{id}")
    public ResponseEntity<HttpStatus> deleteClaim(@PathVariable int id) {
        Claim claim = claimsDB.remove(id);
        if (claim != null) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
}
