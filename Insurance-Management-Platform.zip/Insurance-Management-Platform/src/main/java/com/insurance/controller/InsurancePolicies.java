package com.insurance.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/policies")
public class InsurancePolicies {
	
	 // In-memory database of policies
    private static final Map<Integer, InsurancePolicies> policiesDB = new HashMap<>();
    private static final AtomicInteger policyIdGenerator = new AtomicInteger(1);

    // GET all policies
    @GetMapping
    public ResponseEntity<List<InsurancePolicies>> getAllPolicies() {
        List<InsurancePolicies> policies = new ArrayList<>(policiesDB.values());
        return new ResponseEntity<>(policies, HttpStatus.OK);
    }

    // GET policy by ID
    @GetMapping("/{id}")
    public ResponseEntity<InsurancePolicies> getPolicyById(@PathVariable int id) {
    	InsurancePolicies policy = policiesDB.get(id);
        if (policy != null) {
            return new ResponseEntity<>(policy, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    // POST create a new policy
    @PostMapping
    public ResponseEntity<InsurancePolicies> createPolicy(@RequestBody InsurancePolicies policy) {
        int policyId = policyIdGenerator.getAndIncrement();
        policy.setId(policyId);
        policiesDB.put(policyId, policy);
        return new ResponseEntity<>(policy, HttpStatus.CREATED);
    }

    // PUT update policy information
    @PutMapping("/{id}")
    public ResponseEntity<InsurancePolicies> updatePolicy(@PathVariable int id, @RequestBody InsurancePolicies policy) {
    	InsurancePolicies existingPolicy = policiesDB.get(id);
        if (existingPolicy != null) {
            policy.setId(existingPolicy.getId());
            policiesDB.put(id, policy);
            return new ResponseEntity<>(policy, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    private void setId(Object id) {
		// TODO Auto-generated method stub
		
	}

	private Object getId() {
		// TODO Auto-generated method stub
		return null;
	}

	// DELETE a policy by ID
    @DeleteMapping("/{id}")
    public ResponseEntity<HttpStatus> deletePolicy(@PathVariable int id) {
    	InsurancePolicies policy = policiesDB.remove(id);
        if (policy != null) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

}
