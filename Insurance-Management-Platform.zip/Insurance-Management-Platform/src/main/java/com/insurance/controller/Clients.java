package com.insurance.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.insurance.model.Client;

@RestController
@RequestMapping("/api/clients")
public class Clients {
	
	// In-memory database of clients
    private static final Map<Integer, Client> clientsDB = new HashMap<>();
    private static final AtomicInteger clientIdGenerator = new AtomicInteger(1);

    // GET all clients
    @GetMapping
    public ResponseEntity<List<Client>> getAllClients() {
        List<Client> clients = new ArrayList<>(clientsDB.values());
        return new ResponseEntity<>(clients, HttpStatus.OK);
    }
 // GET client by ID
    @GetMapping("/{id}")
    public ResponseEntity<Client> getClientById(@PathVariable int id) {
        Client client = clientsDB.get(id);
        if (client != null) {
            return new ResponseEntity<>(client, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    // POST create a new client
    @PostMapping
    public ResponseEntity<Client> createClient(@RequestBody Client client) {
        int clientId = clientIdGenerator.getAndIncrement();
        client.setId(clientId);
        clientsDB.put(clientId, client);
        return new ResponseEntity<>(client, HttpStatus.CREATED);
    }

    // PUT update client information
    @PutMapping("/{id}")
    public ResponseEntity<Client> updateClient(@PathVariable int id, @RequestBody Client client) {
        Client existingClient = clientsDB.get(id);
        if (existingClient != null) {
            client.setId(existingClient.getId());
            clientsDB.put(id, client);
            return new ResponseEntity<>(client, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    // DELETE a client by ID
    @DeleteMapping("/{id}")
    public ResponseEntity<HttpStatus> deleteClient(@PathVariable int id) {
        Client client = clientsDB.remove(id);
        if (client != null) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
}
