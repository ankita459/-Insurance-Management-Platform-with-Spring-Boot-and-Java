package com.insurance.model;

import java.time.LocalDate;

public class Claim {
	
	private int claimNumber;
    private String description;
    private LocalDate claimDate;
    private String claimStatus;
    private InsurancePolicy insurancePolicy;
	/**
	 * @param claimNumber
	 * @param description
	 * @param claimDate
	 * @param claimStatus
	 * @param insurancePolicy
	 */
	public Claim(int claimNumber, String description, LocalDate claimDate, String claimStatus,
			InsurancePolicy insurancePolicy) {
		super();
		this.claimNumber = claimNumber;
		this.description = description;
		this.claimDate = claimDate;
		this.claimStatus = claimStatus;
		this.insurancePolicy = insurancePolicy;
	}
	
	// Getter and setter methods
	
	/**
	 * @return the claimNumber
	 */
	public int getClaimNumber() {
		return claimNumber;
	}
	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}
	/**
	 * @return the claimDate
	 */
	public LocalDate getClaimDate() {
		return claimDate;
	}
	/**
	 * @return the claimStatus
	 */
	public String getClaimStatus() {
		return claimStatus;
	}
	/**
	 * @return the insurancePolicy
	 */
	public InsurancePolicy getInsurancePolicy() {
		return insurancePolicy;
	}
	/**
	 * @param claimNumber the claimNumber to set
	 */
	public void setClaimNumber(int claimNumber) {
		this.claimNumber = claimNumber;
	}
	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	/**
	 * @param claimDate the claimDate to set
	 */
	public void setClaimDate(LocalDate claimDate) {
		this.claimDate = claimDate;
	}
	/**
	 * @param claimStatus the claimStatus to set
	 */
	public void setClaimStatus(String claimStatus) {
		this.claimStatus = claimStatus;
	}
	/**
	 * @param insurancePolicy the insurancePolicy to set
	 */
	public void setInsurancePolicy(InsurancePolicy insurancePolicy) {
		this.insurancePolicy = insurancePolicy;
	}

	public void setId1(int claimId) {
		// TODO Auto-generated method stub
		
	}

	public void setId(int claimId) {
		// TODO Auto-generated method stub
		
	}

	public int getId() {
		// TODO Auto-generated method stub
		return 0;
	}
    
}
