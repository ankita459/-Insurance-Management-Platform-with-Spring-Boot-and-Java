package com.insurance.model;

import java.time.LocalDate;

public class InsurancePolicy {
	
	private int policyNumber;
    private String policyType;
    private double coverageAmount;
    private double premium;
    private LocalDate startDate;
    private LocalDate endDate;
    private Client client;
	/**
	 * @param policyNumber
	 * @param policyType
	 * @param coverageAmount
	 * @param premium
	 * @param startDate
	 * @param endDate
	 * @param client
	 */
	public InsurancePolicy(int policyNumber, String policyType, double coverageAmount, double premium,
			LocalDate startDate, LocalDate endDate, Client client) {
		super();
		this.policyNumber = policyNumber;
		this.policyType = policyType;
		this.coverageAmount = coverageAmount;
		this.premium = premium;
		this.startDate = startDate;
		this.endDate = endDate;
		this.client = client;
	}
	
	// Getter and setter methods
	
	/**
	 * @return the policyNumber
	 */
	public int getPolicyNumber() {
		return policyNumber;
	}
	/**
	 * @return the policyType
	 */
	public String getPolicyType() {
		return policyType;
	}
	/**
	 * @return the coverageAmount
	 */
	public double getCoverageAmount() {
		return coverageAmount;
	}
	/**
	 * @return the premium
	 */
	public double getPremium() {
		return premium;
	}
	/**
	 * @return the startDate
	 */
	public LocalDate getStartDate() {
		return startDate;
	}
	/**
	 * @return the endDate
	 */
	public LocalDate getEndDate() {
		return endDate;
	}
	/**
	 * @return the client
	 */
	public Client getClient() {
		return client;
	}
	/**
	 * @param policyNumber the policyNumber to set
	 */
	public void setPolicyNumber(int policyNumber) {
		this.policyNumber = policyNumber;
	}
	/**
	 * @param policyType the policyType to set
	 */
	public void setPolicyType(String policyType) {
		this.policyType = policyType;
	}
	/**
	 * @param coverageAmount the coverageAmount to set
	 */
	public void setCoverageAmount(double coverageAmount) {
		this.coverageAmount = coverageAmount;
	}
	/**
	 * @param premium the premium to set
	 */
	public void setPremium(double premium) {
		this.premium = premium;
	}
	/**
	 * @param startDate the startDate to set
	 */
	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}
	/**
	 * @param endDate the endDate to set
	 */
	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}
	/**
	 * @param client the client to set
	 */
	public void setClient(Client client) {
		this.client = client;
	}
    
    
}
