package com.insurance.model;

import java.time.LocalDate;
import java.util.List;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("com.insurance")
public class Client {
	
	private String name;
    private LocalDate dateOfBirth;
    private String address;
    private String contactInfo;
	/**
	 * @param name
	 * @param dateOfBirth
	 * @param address
	 * @param contactInfo
	 */
	
	
	// Getter and setter methods
	
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * 
	 */
	public Client() {
		super();
		// TODO Auto-generated constructor stub
	}
	/**
	 * @param name
	 * @param dateOfBirth
	 * @param address
	 * @param contactInfo
	 */
	public Client(String name, LocalDate dateOfBirth, String address, String contactInfo) {
		
		this.name = name;
		this.dateOfBirth = dateOfBirth;
		this.address = address;
		this.contactInfo = contactInfo;
	}
	/**
	 * @return the dateOfBirth
	 */
	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}
	/**
	 * @return the address
	 */
	public String getAddress() {
		return address;
	}
	/**
	 * @return the contactInfo
	 */
	public String getContactInfo() {
		return contactInfo;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @param dateOfBirth the dateOfBirth to set
	 */
	public void setDateOfBirth(LocalDate dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	/**
	 * @param address the address to set
	 */
	public void setAddress(String address) {
		this.address = address;
	}
	/**
	 * @param contactInfo the contactInfo to set
	 */
	public void setContactInfo(String contactInfo) {
		this.contactInfo = contactInfo;
	}

	public void setId(int clientId) {
		// TODO Auto-generated method stub
		
	}

	public int getId() {
		// TODO Auto-generated method stub
		return 0;
	}

	public static List<Client> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	public static Object findById(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	public static Client save(Client client) {
		// TODO Auto-generated method stub
		return null;
	}
    
}
