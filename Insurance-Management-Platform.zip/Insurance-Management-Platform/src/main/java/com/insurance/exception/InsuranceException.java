package com.insurance.exception;

import org.springframework.util.AntPathMatcher;

public class InsuranceException extends RuntimeException {
	
	public InsuranceException(AntPathMatcher antPathMatcher) {
        super();
    }
}
